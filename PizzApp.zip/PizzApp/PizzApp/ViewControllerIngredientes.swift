//
//  ViewControllerIngredientes.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/17/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit

class ViewControllerIngredientes: UIViewController,  UITableViewDelegate, UITableViewDataSource {
    
    
    var miPizza : Pizza = Pizza()
    var lista   : [String] = Ingredientes
    
    var numeroIngredientes  : Int = 0
    
    
    @IBOutlet weak var myTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.myTable.dataSource = self
        self.myTable.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        myTable.contentInset = UIEdgeInsetsMake(0,0,0,0);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    override func viewDidAppear(_ animated: Bool) {
        // Revisar si hay algun tamaño seleccionado previamente
        if self.miPizza.ingredientes != nil{
            self.numeroIngredientes = (self.miPizza.ingredientes?.count)!
            print("numero ingredientes = \(self.numeroIngredientes)")
            for index in 0...self.numeroIngredientes-1{
                if let cell = myTable.cellForRow(at: NSIndexPath(row: (self.miPizza.ingredientes?[index])!, section: 0) as IndexPath) {
                    cell.accessoryType = .checkmark
                }
            }
 
        }
    }


    @IBAction func buttonIngredientes(_ sender: AnyObject) {
        
        if self.numeroIngredientes>0{
            // Guardar los elementos seleccionados
            miPizza.ingredientes = nil
            for index in 0...self.lista.count{
                if let cell = myTable.cellForRow(at: NSIndexPath(row: index, section: 0) as IndexPath){
                    if cell.accessoryType == .checkmark{
                        if miPizza.ingredientes == nil {
                            miPizza.ingredientes = [index]
                        }else{
                            miPizza.ingredientes?.append(index)
                        }
                    }
                }
            }
            // Se pone a true este parametro para indicar que ya se han rellenado todos los campos
            self.miPizza.isAllSet = true
            // Se hace el segue a la siguiente vista para ver la configuracion fijada de la pizza
            self.performSegue(withIdentifier: "segueIngredientes", sender: self)
        }
    }
    
    
    
    // El prepare for segue es necesario para pasar el objeto pizza
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let nextView = segue.destination as! ViewControllerFinal
        nextView.miPizza = self.miPizza;
    }
    
    
    
    
    // TableView:
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lista.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let element = lista[indexPath.row]
        
        // Instantiate a cell
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "ElementCell")
        
        // Adding the right informations
        cell.textLabel?.text = element;
        
        // Returning the cell
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        // Ver si el elemento de la tabla clickeado está seleccionado o no
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .checkmark{
                cell.accessoryType = .none
                self.numeroIngredientes = self.numeroIngredientes - 1
            }else{
                if self.numeroIngredientes < 5{
                    cell.accessoryType = .checkmark
                    self.numeroIngredientes = self.numeroIngredientes + 1
                }
            }
        }

        
        
/*
        // Guardar el indice del elemento marcado
        let quesoActualIndex  = indexPath.row
        //let quesoActual = (lista[quesoActualIndex])
        self.miPizza.queso = quesoActualIndex;
        
        // Mostrar y quitar los ticks
        
        let quesoPrevioIndex = self.quesoPrevioIndex
        if let cell = tableView.cellForRow(at: NSIndexPath(row: quesoPrevioIndex, section: 0) as IndexPath){
            cell.accessoryType = .none
        }
        
        if let cell = tableView.cellForRow(at: indexPath) {
            cell.accessoryType = .checkmark
        }
        
        self.quesoPrevioIndex = quesoActualIndex
*/
 
    }

    
    

}
