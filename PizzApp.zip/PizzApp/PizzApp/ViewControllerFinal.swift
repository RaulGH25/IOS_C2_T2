//
//  ViewControllerFinal.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/17/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit

class ViewControllerFinal: UIViewController {
    
    
    var miPizza : Pizza = Pizza()
    
    var listaTamano         : [String] = Tamano
    var listaMasa           : [String] = Masa
    var listaQueso          : [String] = Queso
    var listaIngredientes   : [String] = Ingredientes
    
    
    @IBOutlet weak var labelTamano: UILabel!
    
    @IBOutlet weak var labelMasa: UILabel!
    
    @IBOutlet weak var labelQueso: UILabel!

    
    @IBOutlet weak var labelIngredientes: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        labelTamano.text    = "Tamaño: \(listaTamano[self.miPizza.tamano!])"
        labelMasa.text      = "Tipo de masa: \(listaMasa[self.miPizza.masa!])"
        labelQueso.text     = "Tipo de queso: \(listaQueso[self.miPizza.queso!])"

   
        var numIngredientes : Int = 0
        for ingredienteIndex in self.miPizza.ingredientes!{
            numIngredientes = numIngredientes + 1
        }
 
        var textoIngredientes : String = "Ingredientes: "
        if numIngredientes > 1{
            for index in 0...numIngredientes-2 {
                textoIngredientes += "\(listaIngredientes[(self.miPizza.ingredientes?[index])!]), "
            }
            textoIngredientes += "\(listaIngredientes[(self.miPizza.ingredientes?[numIngredientes-1])!])"
        }else{
            textoIngredientes += "\(listaIngredientes[(self.miPizza.ingredientes?[numIngredientes-1])!])"
        }

        /*
        var textoIngredientes : String = "Ingredientes: "
        for ingredienteIndex in self.miPizza.ingredientes!{
            textoIngredientes += "\(listaIngredientes[ingredienteIndex]), "
        }*/
    
        labelIngredientes.lineBreakMode = .byWordWrapping
        labelIngredientes.numberOfLines = 0
        labelIngredientes.text = textoIngredientes

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    @IBAction func buttonModificarTamano(_ sender: AnyObject) {
        
        self.performSegue(withIdentifier: "segueModificarTamano", sender: self)
        
    }
    
    
    
    @IBAction func buttonModificarMasa(_ sender: AnyObject) {
        
        self.performSegue(withIdentifier: "segueModificarMasa", sender: self)
        
    }
    
    
    
    @IBAction func buttonModificarQueso(_ sender: AnyObject) {
        
        self.performSegue(withIdentifier: "segueModificarQueso", sender: self)
        
    }
    
    
    
    @IBAction func buttonModificarIngredientes(_ sender: AnyObject) {
        
        self.performSegue(withIdentifier: "segueModificarIngredientes", sender: self)
        
    }
    

    @IBAction func buttonFinal(_ sender: AnyObject) {
        
        self.performSegue(withIdentifier: "segueHacerPedido", sender: self)
        
    }
    
    
    
    
    // El prepare for segue es necesario para pasar el objeto pizza
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segueModificarTamano"{
            let nextView = segue.destination as! ViewControllerTamano
            nextView.miPizza = self.miPizza;
        }
        
        if segue.identifier == "segueModificarMasa"{
            let nextView = segue.destination as! ViewControllerMasa
            nextView.miPizza = self.miPizza;
        }
        
        if segue.identifier == "segueModificarQueso"{
            let nextView = segue.destination as! ViewControllerQueso
            nextView.miPizza = self.miPizza;
        }
        
        if segue.identifier == "segueModificarIngredientes"{
            let nextView = segue.destination as! ViewControllerIngredientes
            nextView.miPizza = self.miPizza;
        }
        
        

        
    }

}
