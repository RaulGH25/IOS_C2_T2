//
//  ViewController.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/16/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    var miPizza : Pizza?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    // Cuando se hace click en el boton "Quiero Pizza" se crea un objeto pizza y se inicia la seleccion
    @IBAction func buttonQuieroPizza(_ sender: AnyObject) {
        
        // Se crea el objeto pizza, con atributos nulos, que se van a ir llenando
        self.miPizza = Pizza()
        
        // Se hace el segue a la siguiente vista para decidir el tamaño de la pizza
        self.performSegue(withIdentifier: "segueQuieroPizza", sender: self)
    }
    
    
    // El prepare for segue es necesario para pasar el objeto pizza
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let nextView = segue.destination as! ViewControllerTamano
        nextView.miPizza = self.miPizza!;
    }
    
    
    
    
}

